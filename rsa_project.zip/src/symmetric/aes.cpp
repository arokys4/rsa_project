// AES implementation
