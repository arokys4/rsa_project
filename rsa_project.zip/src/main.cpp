// main entry
int main(){return 0;}
